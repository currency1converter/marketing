<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Strict//EN">

<head>
	<title>Your message has been sent!</title>
	
</head>

<body>
		
	<h1>Your message has been sent!</h1>

</body>
</html>